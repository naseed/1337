/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mochihab <mochihab@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/19 11:05:03 by mochihab          #+#    #+#             */
/*   Updated: 2025/07/20 15:59:32 by mochihab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_line(int len, char first, char midl, char last)
{
	int	i;

	i = 0;
	while (i <= len)
	{
		if (i == 0)
		{
			ft_putchar(first);
		}
		else if (i < len - 1)
		{
			ft_putchar(midl);
		}
		else if (i == len - 1)
		{
			ft_putchar(last);
		}
		i++;
	}
	ft_putchar('\n');
}

void	error_message(void)
{
	char	*str;

	str = "Error! : You must enter an integer > 0";
	while (*str)
	{
		ft_putchar (*str);
		str++;
	}
}

void	rush(int x, int y)
{
	int	j;

	if (x <= 0 || y <= 0)
	{
		error_message ();
		return ;
	}
	j = 0;
	while (j <= y)
	{
		if (j == 0)
		{
			print_line (x, 'A', 'B', 'C');
		}
		else if (j < y - 1)
		{
			print_line (x, 'B', ' ', 'B');
		}
		else if (j == y - 1)
		{
			print_line (x, 'A', 'B', 'C');
		}
		j++;
	}
}
